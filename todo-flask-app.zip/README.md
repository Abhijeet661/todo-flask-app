# To-Do Task Manager (Flask)

A simple to-do list web app built using Flask and SQLite.

## Features
- Add new task
- Delete task
- View all tasks

## Tech Stack
- Python
- Flask
- SQLite
- Bootstrap (UI)

## How to Run
```bash
pip install flask flask_sqlalchemy
python app.py
```